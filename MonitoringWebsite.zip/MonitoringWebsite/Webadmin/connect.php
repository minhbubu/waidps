 <?php 
 	mysql_connect("localhost","root","") or die ("no connect");
  	mysql_select_db("monitornetwork");
  	mysql_query("set names 'utf8'");
 ?>