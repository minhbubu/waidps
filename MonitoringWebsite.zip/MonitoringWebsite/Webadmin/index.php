<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>WAIDPS Monitoring</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bootstrap/css/ionicons.min.css">
  <link rel="stylesheet" type="text/css" href=plugins/datatables/jquery.dataTables.min.css>
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/main.css">
  <!-- main Skins. Choose a skin from the css/skins
  folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini" style="font-family: Antiqua">
  <?php
  include ('session.php');
  include_once ('config.php');

  ?>
  <div class="wrapper">

    <header class="main-header">
      <!-- Logo -->
      <a href="index.php" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>Wi</b>Mo</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>WAIDPS</b> Monitoring</span>
      </a>

      <!-- Header Navbar: style can be found in header.less -->
      <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
          <span class="sr-only">Toggle navigation</span>
        </a>
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <!-- Notifications: style can be found in dropdown.less -->
            <!-- <li class="dropdown notifications-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-bell-o"></i>
               
              </a>            
            </li> -->
            <!-- User Account: style can be found in dropdown.less -->
            <li class="dropdown user user-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <img src="dist/img/avatar.jpg" class="user-image" alt="User Image">
                <span class="hidden-xs">Administrator</span>
              </a>
              <ul class="dropdown-menu">
                <!-- User image -->
                <li class="user-header">
                  <img src="dist/img/avatar.jpg" class="img-circle" alt="User Image">

                  <p>
                    Administrator
                  </p>
                </li>
                <!-- Menu Footer-->
                <li class="user-footer">
                <!-- <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div> -->
                <div style="padding: 0px 90px ; background-color: #f9f9f9">
                  <a href="pages/auth/logout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>          
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="dist/img/avatar1.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
         
          <p>Administrator</p>
          <!-- <a href="#"><i class="fa fa-circle text-success"></i> Online</a> -->
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview">
          <a href="#">
            <i class="fa fa-home" style="font-size: 25px">  </i> 
            <span style="padding-left: 15px; font-size: 15px"> Home Page</span>            
          </a>          
        </li>
        <li class="treeview">
          <a href="pages/infoAP.php">
            <i class="fa fa-wifi"  style="font-size: 25px"></i>
            <span style="padding-left: 15px; font-size: 15px">Access Points List</span>
          </a>
        </li>        
        <!-- <li class="treeview">
          <a href="#">
            <i class="fa fa-laptop"></i>
            <span>Attack Detected</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/WEPattack.php"><i class="fa fa-circle-o"></i> WEP Attack</a></li>
            <li><a href="pages/WPAattack.php"><i class="fa fa-circle-o"></i> WPA Attack</a></li>
            <li><a href="pages/FloodAttack.php"><i class="fa fa-circle-o"></i> Flood attack</a></li>
            <li><a href="pages/Evil-twins.php"><i class="fa fa-circle-o"></i> Rogue Access Point, Evil-twins</a></li>
          </ul>
        </li> -->
        </ul>
      </section>
      <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content"> 
        <!--  <h2 class="page-header">WIDS and AccessPoint</h2> -->
        <div class="row">
          <div class="col-md-4 col-sm-4">
            <div class="box box-default" >
              <div class="box-header with-border">
               
                <h3 class="box-title" style="font-weight: bold; text-shadow: 4px 1px 4px #3c76a9; font-family: Ar"> <i class="fa fa-rss-square"></i> WIDS</h3>
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                <table id= "wids_table" class="display compact" cellspacing="0" width="100%" >
                  <thead>
                    <tr >
                      <th>WIDS</th>
                      <th>MAC</th>
                      <th>IP</th>
                      <th>Active</th>
                    </tr>
                  </thead>
                </table>

              </div>
              <!-- /.box-body -->
            </div>
            <!-- /.box -->
          </div>
          <!-- /.col -->
          <div class="col-md-8">
            <div class="box box-default">
              <div class="box-header with-border ">
                
                <h3 class="box-title"  style=" font-weight: bold; text-shadow: 4px 1px 4px #3c76a9; font-family: Antiqua"> <i class="fa fa-wifi"></i> Access Point</h3>
              </div>
              <!-- /.box-header -->
              <div class="box-body"> 
                <table id="ap_table" class="display compact" cellspacing="0" width="100%" >
                  <thead>
                    <tr >
                      <th>ID</th>
                      <th>WIDS</th>
                      <th>SSID</th>
                      <th>Power</th>
                      <th>Channel</th>
                      <th>Privacy</th>
                      <th>Authentication</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                      <div class="modal fade" id="ap_detail_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog" width="50" >
                          <div class="modal-content" style="background-color:#81DAF5;border-radius: 15px">
                            <div class="modal-header" style= "background-color: white; border-radius: 10px">
                              <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                              <h4 class="modal-title" style="color: blue ;text-align: center;" id="myModalLabel"><strong>ACCESSPOINT INFO</strong></h4>
                            </div>
                            <div id= "bodymodal" class="modal-body">
                                <div id="apwids_detail"></div>
                                <div id="apESSID_detail"></div>
                                <div id="apBSSID_detail"></div>
                                <div id="apPower_detail"></div>
                                <div id="apChannel_detail"></div>
                                <div id="apPrivacy_detail"></div>
                                <div id="apMaxrate_content"></div>
                                <div id="apAuthen_detail"></div>
                                <div id="apCipher_content"></div>
                                <div id="apMode_content"></div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                            </div>
                          </div>
                        </div>
                      </div>
                </table>

              </div>
              <!-- /.box-body -->
            </div>
            <!-- /.box -->
          </div>
        </div>
        
        <div class="box box-default">
          <div class="box-header with-border">
            <i  style="color: #FE424E " class="fa  fa-warning "></i>
            <h3 class="box-title" style="color: #FE424E;  text-shadow: 10px 2px 9px #f56666;font-family: Ar; font-size: 23px"><b>Attack and Warning</b> </h3>
          </div>
          <div class="box-body" >
            <!-- <div class="container warning"> -->
              <ul class="nav nav-tabs device " role="tablist" >
                <li  class="active"><a data-toggle="tab" style="color: blue;  padding: 8px 15px;" role="tab" href="#charts"><b><i class="fa fa-bar-chart"></i> Attack Overview </b></a></li>
                <li><a data-toggle="tab" style="color: #DD0000;  padding: 8px 15px;" role="tab" href="#attacklog"><b><i class="fa fa-user-secret"></i> Attack Log</b></a></li>
                <li><a data-toggle="tab" role="tab" style="color: #FFA50A;  padding: 8px 15px;" href="#warnings"><b><i class="fa fa-exclamation-triangle"></i> Warning</b></a></li>
                
              </ul>

              <div class="tab-content .device-background-content ">
                <div id="charts" class="tab-pane fade in active " >
                  <div class="box box-solid">
                    <div class="box-header">
                      <h3 class="box-title text-warning" style="text-align: center; display: block; font-weight: bold; font-family: Antiqua">Attack Overview  </h3>

                      <div class="box-tools pull-right">
                        <button  id = "refresh" type="button" class="btn btn-default " ><i class="fa fa-refresh"></i></button>
                      </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body text-center">
                      <canvas id="myChart" width="200" height="60" style="margin-top: 20px;"></canvas>
                    </div>
                    <!-- /.box-body -->
                  </div>
                  
                    
                </div>
                <div id="attacklog" class="tab-pane fade" >
                  <table id= "attack_table" class="display compact" cellspacing="0" width="100%">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Time</th>
                        <th>Attack Type</th>
                        <th>Target SSID</th>
                        <th>Target BSSID</th>
                      </tr>
                    </thead>

                    <div class="modal fade" id="attack_detail_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                      <div class="modal-dialog" >
                        <div class="modal-content" style="background-color: Pink; border-radius: 15px">
                          <div class="modal-header" style= "background-color: white; border-radius: 10px">
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                            <h4 class="modal-title"  style="color: red; text-align: center;" id="myModalLabel"><strong>ATTACK INFO</strong></h4>
                          </div>
                          <div id= "bodymodal" class="modal-body">
                              <div id="reported_detail"></div>
                              <div id="atttype_detail"></div>
                              <div id="attdetail_detail"></div>
                              <div id="attnote_detail"></div>
                              <div id="packet_detail"></div>
                              <div id="frMAC_detail"></div>
                              <div id="frMacinfo_detail"></div>
                              <div id="toMac_detail"></div>
                              <div id="toMacinfo_detail"></div>
                              <div id="toBSSID_detail"></div>
                              <div id="toBSSIDifno_detail"></div>
                          </div>
                          <div class="modal-footer" >
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                          </div>
                        </div>
                      </div>
                    </div>

                  </table>

                </div>
                <div id="warnings" class="tab-pane fade">
                  <table id= "warning_table" class="display" cellspacing="0" width="100%">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Time</th>
                        <th>WarmingType</th>
                        <th>WarningInfo</th>
                      </tr>
                    </thead>
                     <div class="modal fade" id="warning_detail_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color:#FCEF79;border-radius: 15px">
                          <div class="modal-header" style= "background-color: white; border-radius: 10px">
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                            <h4 class="modal-title" style="color: orange ;text-align: center;" id="myModalLabel"><strong>WARNING INFO</strong></h4>
                          </div>
                          <div id= "bodymodal" class="modal-body">

                              <div id="wreported_detail"></div>
                              <div id="wids_detail"></div>
                              <div id="cautious_detail"></div>
                              <div id="cautype_detail"></div>
                              <div id="cauinfo_detail"></div>
                              <div id="caudetail_detail"></div>
                              <div id="caudetail_content"></div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                          </div>
                        </div>
                      </div>
                    </div>
                  </table>
                </div>
                
              </div>
          </div>
        </div>
        
        </section>

  </div>
  
  <footer class="main-footer">
    <p>WAIDPS Monitoring - Copyright© 2016 by Hạnh Nguyễn</p>
  </footer>
</div>
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="plugins/jQuery/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.min.js"></script> 
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/chartjs/chart/Chart.min.js"></script>
<script src="plugins/chartjs/chart/Chart.js"></script>
<script src="plugins/chartjs/chart/Chart.bundle.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/chartjs/chart/Chart.bundle.min.js"></script>

<script src="dist/js/app.min.js"></script> 
<script scr="plugins/jQuery/json2.min.js"></script> 

<script type="text/javascript">
  $(document).ready(function (e) {
   var wids_table= $('#wids_table').DataTable( {
    "searching": false,
    "lengthChange": false,
    "ordering": false,  
    "paging": false, 
    "info": false,
    "scrollY": 180,
    "bAutoWidth":false,
    //"fixedHeader": true,
    "columns": [
                    // { "data": "bssid" },
                    { "data": "WIDS" },
                    { "data": "MAC" },
                    { "data": "IP" },
                    { "data": "Active" }
                    ]
                  } );
   wids_table.column(3).visible(false);
   wids_table.ajax.url("./loaddata.php?action=get-wids").load();

 /// table ap
  var ap_table= $('#ap_table').DataTable( {
        "searching": false,
        //"bProcessing": true,
        "bSort": true,
        "ordering": true,
        "select": true,
        "paging": false,
        "info": false,
        "lengthChange": false,
        "bAutoWidth":false,
        "scrollY": 180,
        //"scrollX": true,
    "columns": [
                    // { "data": "bssid" },
                    { "data": "ID" },
                    { "data": "WIDS" },
                    { "data": "ESSID" },
                    { "data": "Power" },
                    { "data": "Channel" },
                    { "data": "Privacy" },
                    { "data": "Authentication" },
                    { "data": "Status" }
                    ]
  } );
  ap_table.column(0).visible(false);
  ap_table.column(1).visible(false);
  // click wids show list access point
  
  $('#wids_table tbody').on( 'click', 'tr', function () {
    if ( $(this).hasClass('selected') ) {
      $(this).removeClass('selected');
    }
    else {
      wids_table.$('tr.selected').removeClass('selected');
      $(this).addClass('selected');
    }
    var wids =  wids_table.row( this ).data()['WIDS'];
    var mac =  wids_table.row( this ).data()['MAC'];
    var active =  wids_table.row( this ).data()['Active'];
    ap_table.ajax.url("./loaddata.php?action=get-ap&wids="+wids+"&mac="+mac).load();
    setInterval(function() {
      if (active == 0) { 
        ap_table.load();
      } 
    },2000);

  } );
  // click button change status
  $('#ap_table tbody').on( 'click', 'button', function () {
        //var table_ap = $('#ap_table').DataTable();
        var idap = ap_table.row($(this).parents('tr')).data()['ID'];
        var stt= ap_table.row($(this).parents('tr')).data()['Status'];
   
        var wids =  ap_table.row($(this).parents('tr')).data()['WIDS'];
        ap_table.ajax.url("./loaddata.php?action=get-status&ID="+idap+"&stt="+stt+"&wids="+wids).load();
        attack_table.ajax.url("./loaddata.php?action=get-attack").load();
        
    } );
// Select ap show detail
  $('#ap_table tbody').on( 'click', 'tr', function () {
    if ( $(this).hasClass('selected') ) {
      $(this).removeClass('selected');
    }
    else {
      ap_table.$('tr.selected').removeClass('selected');
      $(this).addClass('selected');
    }
    var idap =  ap_table.row( this ).data()['ID'];
    $.get("./loaddata.php?action=get-ap_detail&ID="+idap, function( data, status ) {
      var obj = jQuery.parseJSON(JSON.stringify(data));
      //console.log(obj);
      $('#ap_detail_modal').modal('show');
      document.getElementById('apwids_detail').innerHTML = "<b>WIDS:  </b>" + obj[0]['WIDS'];
      document.getElementById('apESSID_detail').innerHTML = "<b>SSID:   </b>" + obj[0]['ESSID'];
      document.getElementById('apBSSID_detail').innerHTML = "<b>BSSID:   </b>" + obj[0]['BSSID'];
      document.getElementById('apPower_detail').innerHTML = "<b>Power:   </b>"+ obj[0]['Power'];
      document.getElementById('apChannel_detail').innerHTML = "<b>Channel:   </b>"  + obj[0]['Channel'];
      document.getElementById('apPrivacy_detail').innerHTML = "<b>Privacy:   </b>"+obj[0]['Privacy'];
      document.getElementById('apMaxrate_content').innerHTML = "<b>MaxRate:   </b>"+obj[0]['MaxRate'];
      document.getElementById('apAuthen_detail').innerHTML = "<b>Authentication:   </b>"+obj[0]['Authentication'];
      document.getElementById('apCipher_content').innerHTML = "<b>Cipher:  </b>"+obj[0]['Cipher'];
      document.getElementById('apMode_content').innerHTML = "<b>Mode:   </b>"+obj[0]['Mode'];
      //document.getElementById('toBSSIDifno_detail').innerHTML = "<b>BSSID info:   </b>"+obj[0]['ToBSSIDInfo']; 

    });

  });

 var attack_table= $('#attack_table').DataTable( {
    "searching": false,
    "lengthChange": false,
    "ordering": false,  
    "paging": false, 
    "info": false,
    "scrollY": 180,
    "bAutoWidth":false,
    "scrollY": 200,
      "columns": [
      { "data": "ID" },
      { "data": "Reported" },
      { "data": "AttType" },
      { "data": "ESSID" },
      { "data": "ToBSSID" }
      ]
    } );
  attack_table.column(0).visible(false);
  attack_table.ajax.url("./loaddata.php?action=get-attack").load();
  $('#attack_table tbody').on( 'click', 'tr', function () {
    if ( $(this).hasClass('selected') ) {
      $(this).removeClass('selected');
    }
    else {
      attack_table.$('tr.selected').removeClass('selected');
      $(this).addClass('selected');
    }
    var id =  attack_table.row( this ).data()['ID'];
    $.get("./loaddata.php?action=get-attackdetail&ID="+id, function( data, status ) {
   
    var obj = jQuery.parseJSON(JSON.stringify(data));
    //console.log(obj);
      $('#attack_detail_modal').modal('show');
      document.getElementById('reported_detail').innerHTML = "<b>Reported:   </b>" + obj[0]['Reported'];
      document.getElementById('atttype_detail').innerHTML = "<b>Attack type:   </b>" + obj[0]['AttType'];
      document.getElementById('attdetail_detail').innerHTML = "<b>Attack detail:   </b>" + obj[0]['AttDetails'];
      document.getElementById('attnote_detail').innerHTML = "<b>Attack note:   </b>"+ obj[0]['AttNotes'];
      document.getElementById('packet_detail').innerHTML = "<b>Packet:   </b>"  + obj[0]['Packets'];
      document.getElementById('frMAC_detail').innerHTML = "<b>From Mac address:   </b>"+obj[0]['FrMAC'];
      document.getElementById('frMacinfo_detail').innerHTML = "<b>From Mac info:   </b>"+obj[0]['FrMACInfo'];
      document.getElementById('toMac_detail').innerHTML = "<b>To Mac address:   </b>"+obj[0]['ToMAC'];
      document.getElementById('toMacinfo_detail').innerHTML = "<b>To Mac info:   </b>"+obj[0]['ToMACInfo'];
      document.getElementById('toBSSID_detail').innerHTML = "<b>BSSID:   </b>"+obj[0]['ToBSSID'];
      document.getElementById('toBSSIDifno_detail').innerHTML = "<b>BSSID info:   </b>"+obj[0]['ToBSSIDInfo']; 

    });
  } );
  var warning_table= $('#warning_table').DataTable( {
  "searching": false,
  "lengthChange": false,
  "ordering": false,  
  "paging": false, 
  "info": false,
  "bAutoWidth":false,
  "scrollY": 200,
  "columns": [
            { "data": "ID" },
            { "data": "Reported" },
            { "data": "CauType" },
            { "data": "CauInfo" }
            ]
  } );
  warning_table.column(0).visible(false);
  warning_table.ajax.url("./loaddata.php?action=get-warning").load();
  
  $('#warning_table tbody').on( 'click', 'tr', function () {
    if ( $(this).hasClass('selected') ) {
      $(this).removeClass('selected');
    }
    else {
      warning_table.$('tr.selected').removeClass('selected');
      $(this).addClass('selected');
    }
    var id_war =  warning_table.row( this ).data()['ID'];
    $.get("./loaddata.php?action=get-warningdetail&ID="+id_war, function( data, status ) {
   
    var objs = jQuery.parseJSON(JSON.stringify(data));
    //console.log(obj);
    $('#warning_detail_modal').modal('show');

    document.getElementById('wreported_detail').innerHTML = "<b>Reported: </b>" + objs[0]['Reported'];
    document.getElementById('wids_detail').innerHTML = "<b>WIDS name: </b>" + objs[0]['WIDS'];
    document.getElementById('cautious_detail').innerHTML = "<b>Cautious number: </b>" + objs[0]['Cautious'];
    document.getElementById('cautype_detail').innerHTML = "<b>Warning type: </b>"+ objs[0]['CauType'];
    document.getElementById('cauinfo_detail').innerHTML = "<b>Warning Info: </b>" + objs[0]['CauInfo'];
    document.getElementById('caudetail_detail').innerHTML = "<b> Warning detail: </b>" ;
    document.getElementById('caudetail_content').innerText = "------" + objs[0]['CauDetails'];
   
    //alert (objs[0]['Reported']);
    });
  });


  // Chart
  var ctx = document.getElementById("myChart").getContext("2d");

    $.get("./loaddata.php?action=get-chart", function( data, status ) {
   
    var objs = jQuery.parseJSON(data);
       
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["Association/Authentication Flood", "Deauthentication Attack","Beacon Flooding Attack","WEP Attack","WPA Attack","Rogue Access Point","WIDS/WIPS/WDS Confusion","WPS - PIN Bruteforce","TKIPTUN-NG Injection","Basic Probing & ESSID BruteForce","Michael Shutdown Exploitation"],
            datasets: [{
                label: 'Attack number',  
                data: [objs[0],objs[1],objs[2],objs[3],objs[4],objs[5],objs[6],objs[7],objs[8],objs[9],objs[10]],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(237, 6, 202, 0.2)',
                    'rgba(4, 37, 253, 0.2)',
                    'rgba(14, 255, 243, 0.2)',
                    'rgba(14, 255, 23, 0.2)',
                    'rgba(49, 248, 14, 0.2)'
                ],
                borderColor: [
                    'rgba(255,99,132,1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(237, 6, 202, 1)',
                    'rgba(4, 37, 253, 1)',
                    'rgba(14, 255, 243, 1)',
                    'rgba(14, 255, 23, 0.2)',
                    'rgba(49, 248, 14, 1)'
                ],
                borderWidth: 1,
            }]
        },
        options: {
            //responsive: true,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
                
            },
             legend: {
                display: false
              },
              tooltips: {
                  callbacks: {
                     label: function(tooltipItem) {
                            return tooltipItem.yLabel;
                     }
                  }
              }
        }


      }); 

  });
  $('#refresh' ).on( 'click', function () {
    $.get("./loaddata.php?action=get-chart", function( data, status ) {
   
    var objs = jQuery.parseJSON(data);
       
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["Association/Authentication Flood", "Deauthentication Attack","Beacon Flooding Attack","WEP Attack","WPA Attack","Rogue Access Point","WIDS/WIPS/WDS Confusion","WPS - PIN Bruteforce","TKIPTUN-NG Injection","Basic Probing & ESSID BruteForce","Michael Shutdown Exploitation"],
            datasets: [{
                label: 'Attack number',  
                data: [objs[0],objs[1],objs[2],objs[3],objs[4],objs[5],objs[6],objs[7],objs[8],objs[9],objs[10]],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(237, 6, 202, 0.2)',
                    'rgba(4, 37, 253, 0.2)',
                    'rgba(14, 255, 243, 0.2)',
                    'rgba(14, 255, 23, 0.2)',
                    'rgba(49, 248, 14, 0.2)'
                ],
                borderColor: [
                    'rgba(255,99,132,1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(237, 6, 202, 1)',
                    'rgba(4, 37, 253, 1)',
                    'rgba(14, 255, 243, 1)',
                    'rgba(14, 255, 23, 0.2)',
                    'rgba(49, 248, 14, 1)'
                ],
                borderWidth: 1,
            }]
        },
        options: {
            //responsive: true,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
                
            },
             legend: {
                display: false
              },
              tooltips: {
                  callbacks: {
                     label: function(tooltipItem) {
                            return tooltipItem.yLabel;
                     }
                  }
              }
        }


      }); 

    });

  });
// 
  
  // //set time reload table 
  setInterval(function() {

    wids_table.ajax.url("./loaddata.php?action=get-wids").load(); 
	if (! wids_table.data().count()){
		ap_table.clear().draw();
	}
    warning_table.ajax.url("./loaddata.php?action=get-warning").load();
    attack_table.ajax.url("./loaddata.php?action=get-attack").load();
    
    //ap_table.load();
  
  }, 2000);
});

</script>
</body>
</html>
