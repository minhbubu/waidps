<?php
   require_once ('session.php');
   	$action = "";
   	if (isset($_REQUEST['action'])){
   		$action = $_REQUEST['action'];
   	}
   	if ($action=="get-wids"){
   		require_once ("database.php");
   		$sql = db_select($conn, "wids", ['WIDS','MAC','IP','Active'], "Active=1");
   		$json_string = json_encode($sql);
   		$json_string = "{ \"data\": $json_string}";
   		header('Content-Type: application/json');
   		echo $json_string;
   	}
   	elseif ($action=="get-widss"){
   		require_once ("database.php");
   		$sql = db_select($conn, "wids", ['WIDS','MAC','IP','Active'],"1");
   		$json_string = json_encode($sql);
   		$json_string = "{ \"data\": $json_string}";
   		header('Content-Type: application/json');
   		echo $json_string;
   	}
   	elseif ($action=="get-ap") {
   		if (isset($_REQUEST['wids'])){
   			$wids = $_REQUEST['wids'];
   			require_once ("database.php");
	   		$sql = db_select($conn, "accesspoint", ['ID','WIDS','ESSID','Channel','Authentication','Privacy','Power','Status'], "WIDS='$wids' AND Active=1");
	   		for ($i=0; $i < count($sql); $i++) { 

	   			if ($sql[$i]['Status'] == 0){
			 		$sql[$i]['Status'] = "<button type=\"button\" class=\"btn btn-danger\">Untrust</button>";	
	   			}
	   			elseif ($sql[$i]['Status'] == 1) {
	   				$sql[$i]['Status'] = "<button type=\"button\" class=\"btn btn-success\">Trusted</button>";
	   				
	   			}
			 	
	   		}
	   		$json_string = json_encode($sql);
	   		$json_string = "{ \"data\": $json_string}";
	   		header('Content-Type: application/json');
	   		echo $json_string;
   		}	
   	}
   	elseif ($action=="get-ap_detail") {
   		if (isset($_REQUEST['ID'])){
   			$id = $_REQUEST['ID'];
   			require_once ("database.php");
   			$sql = db_select($conn, "accesspoint", ['ID','WIDS','ESSID','BSSID','Channel','Privacy','Authentication','Cipher','Mode','Power','MaxRate','WPS','Reported','Status'],"ID='$id'");
   		
   		$json_string = json_encode($sql);
   		//$json_string = "{ \"data\": $json_string}";
   		header('Content-Type: application/json');
   		echo $json_string;
   		}
   	}
   	elseif ($action=="get-apinfo") {
   		require_once ("database.php");
   		$sql = db_select($conn, "accesspoint", ['ID','WIDS','ESSID','BSSID','Channel','Privacy','Authentication','Cipher','Mode','Power','MaxRate','WPS','Reported','Status'],"Active=1");
   		for ($i=0; $i < count($sql); $i++) { 

	   			if ($sql[$i]['Status'] == 0){
			 		$sql[$i]['Status'] = "<button type=\"button\" class=\"btn btn-danger\">Untrust</button>";	
	   			}
	   			elseif($sql[$i]['Status'] == 1) {
	   				$sql[$i]['Status'] = "<button type=\"button\" class=\"btn btn-success\">Trusted</button>";
	   				
	   			}
	   		}
   		$json_string = json_encode($sql);
   		$json_string = "{ \"data\": $json_string}";
   		header('Content-Type: application/json');
   		echo $json_string;
   	}
   	elseif ($action=="get-attack") {
   		require_once ("database.php");
   		$sql= db_selectat($conn);

   		//$sql = db_selectat($conn, "attack", ['Reported','AttType','ToBSSID','ID'], "1 ORDER BY Reported DESC");

   		for ($i=0; $i < count($sql) ; $i++) { 
   			$mac= $sql[$i]['ToBSSID'];
   			$query= db_select($conn,"accesspoint",['BSSID'],"BSSID='$mac' AND Status=1");

   			if (count($query)> 0) {
   				//echo ("<div style=\"color: red\">" . $sql[$i]['ToBSSID'] ."</div>");
   				$sql[$i]['Reported']="<div style=\"color: red\">" . $sql[$i]['Reported'] ."</div>";
   				$sql[$i]['AttType']="<div style=\"color: red\">" . $sql[$i]['AttType'] ."</div>";
   				$sql[$i]['ESSID']="<div style=\"color: red\">" . $sql[$i]['ESSID'] ."</div>";
   				$sql[$i]['ToBSSID']="<div style=\"color: red\">" . $sql[$i]['ToBSSID'] ."</div>";

   			}
   		}

   		$json_string = json_encode($sql);
   		$json_string = "{ \"data\": $json_string}";
   		header('Content-Type: application/json');
   		echo $json_string;
   	}
   	elseif ($action=="get-attackdetail") {
   		if (isset($_REQUEST['ID'])){
   			$ID_attack = $_REQUEST['ID'];
   			//echo ($ID_attack);
	   		require_once ("database.php");
	   		$sql = db_select($conn, "attack", ['Reported','AttType', 'AttDetails', 'AttNotes', 'Packets','FrMAC', 'FrMACInfo', 'ToMAC','ToMACInfo','ToBSSID','ToBSSIDInfo'], "ID=$ID_attack ");

	   		$json_string = json_encode($sql);
	   		header('Content-Type: application/json');
	   		echo $json_string;
   		}	
   }
   elseif ($action=="get-warning") {

	   		require_once ("database.php");

	   		$sql = db_select($conn, "cautious", ['ID','Reported','CauType', 'CauInfo'], "1 ORDER BY Reported DESC");

	   		$json_string = json_encode($sql);
	   		$json_string = "{ \"data\": $json_string}";
	   		header('Content-Type: application/json');
	   		echo $json_string;
   			
   }
   	elseif ($action=="get-warningdetail") {
   		if (isset($_REQUEST['ID'])){
   			$ID_warning = $_REQUEST['ID'];
   			//echo ($ID_attack);
	   		require_once ("database.php");
	   		$sql = db_select($conn, "cautious", ['Reported','WIDS','CauType','Cautious', 'CauInfo', 'CauDetails'], "ID=$ID_warning");

	   		$json_string = json_encode($sql);
	   		header('Content-Type: application/json');
	   		echo $json_string;
   		}
   }
   	elseif ($action=="get-status") {

	   	if (isset($_REQUEST['ID'])){//khong can dau
	   		require_once ("database.php");
			$idap = $_REQUEST['ID'];
			$stt = $_REQUEST['stt'];
			//echo $stt;
			$wids = $_REQUEST['wids'];
	   		if ($stt == "<button type=\"button\" class=\"btn btn-danger\">Untrust</button>") { 
	   			db_update($conn, "accesspoint", ['Status'],"1","ID='$idap'");
	   			
	   		} 
	   		elseif ($stt == "<button type=\"button\" class=\"btn btn-success\">Trusted</button>") {
	   			
	   			db_update($conn, "accesspoint", ['Status'],"0","ID='$idap'");
	   			
	   		}
	   		$sql = db_select($conn, "accesspoint", ['ID','WIDS','ESSID','Channel','Authentication','Power','Privacy','Status'], "WIDS='$wids' AND Active=1");
	   		for ($i=0; $i < count($sql); $i++) { 

	   			if ($sql[$i]['Status'] == 0){
			 		$sql[$i]['Status'] = "<button type=\"button\" class=\"btn btn-danger\">Untrust</button>";
			 		//no gan biên stt chỗ này 	
	   			}
	   			elseif($sql[$i]['Status'] == 1) {
	   				$sql[$i]['Status'] = "<button type=\"button\" class=\"btn btn-success\">Trusted</button>";
	   				
	   			}
		   	}
		   	$json_string = json_encode($sql);
	   		$json_string = "{ \"data\": $json_string}";
	   		//header('Content-Type: application/json');
	   		echo $json_string;
		} 

	} 
	elseif ($action=="get-statusap") {

	   	if (isset($_REQUEST['ID'])){
	   		require_once ("database.php");
			$idap = $_REQUEST['ID'];
			$stt = $_REQUEST['stt'];
			
	   		if ($stt == "<button type=\"button\" class=\"btn btn-danger\">Untrust</button>") { 
	   			db_update($conn, "accesspoint", ['Status'],"1","ID='$idap'");
	   			
	   		} 
	   		elseif ($stt == "<button type=\"button\" class=\"btn btn-success\">Trusted</button>") {
	   			
	   			db_update($conn, "accesspoint", ['Status'],"0","ID='$idap'");
	   			
	   		}
	   		$sql = db_select($conn, "accesspoint", ['ID','WIDS','ESSID','BSSID','Channel','Privacy','Authentication','Cipher','Mode','Power','MaxRate','WPS','Reported','Status'],"Active=1");
	   		for ($i=0; $i < count($sql); $i++) { 

	   			if ($sql[$i]['Status'] == 0){
			 		$sql[$i]['Status'] = "<button type=\"button\" class=\"btn btn-danger\">Untrust</button>";
			 		//no gan biên stt chỗ này 	
	   			}
	   			elseif($sql[$i]['Status'] == 1) {
	   				$sql[$i]['Status'] = "<button type=\"button\" class=\"btn btn-success\">Trusted</button>";
	   				
	   			}
		   	}
		   	$json_string = json_encode($sql);
	   		$json_string = "{ \"data\": $json_string}";
	   		//header('Content-Type: application/json');
	   		echo $json_string;
		} 

	} 
	elseif ($action=="get-chart") {

		require_once ("database.php");
		$flood = db_select($conn, "attack",['AttType'], "AttType = 'Association Flood' OR AttType LIKE  'Authentication Flood%' OR AttType = 'Association/Authentication Flood' OR AttType='MDK3 - Authentication DoS (a) to Multiple Access Points'");
		$flood_num= Count($flood);
		//echo $flood_num;
		$deauthen = db_select($conn, "attack", ['AttType'], "AttType = 'Deauthentication Attack'");
		$deauthen_num = Count($deauthen);
		//echo $deauthen_num;
		$beacon = db_select($conn, "attack", ['AttType'], "AttType = 'MDK3 - Beacon Flooding Mode' OR AttType = 'MDK3 - Beacon Flooding Mode (Similar ESSID)'");
		$beacon_num = Count($beacon);
		//echo $beacon_num;
		$wep = db_select($conn, "attack", ['AttType'], "AttType = 'WEP - ARP-Replay Request' OR AttType = 'WEP - KoreK Chopchop'");
		$wep_num = Count($wep);
		//echo $wep_num;
		$wpa = db_select($conn, "attack", ['AttType'], "AttType = 'Deauthentication - WPA Handshake' OR AttType='MDK3 - WPA Downgrade Test / Deauthentication/Disassociation Amok Mode'");
		$wpa_num= Count($wpa);
		//echo $wpa_num;
		$rogue = db_select($conn, "attack", ['AttType'], "AttType ='Rogue Access Point'");
		$rogue_num = Count($rogue);
		//echo $rogue_num;
		$confusion =  db_select($conn, "attack", ['AttType'], "AttType ='MDK3 - WIDS/WIPS/WDS Confusion Mode - Single' OR AttType='MDK3 - WIDS/WIPS/WDS Confusion Mode - Multiple'");
		$confusion_num = Count($confusion);
		//echo $confusion_num;
		$bruteforce = db_select($conn, "attack", ['AttType'], "AttType LIKE 'WPS - PIN Bruteforce%' ");
		$bruteforce_num = Count($bruteforce);
		//echo $bruteforce_num;
		$tkip =  db_select($conn, "attack", ['AttType'], "AttType= 'TKIPTUN-NG Injection'");
		$tkip_num = Count($tkip);
		//echo $tkip_num;
		$basic =  db_select($conn, "attack", ['AttType'], "AttType= 'MDK3 - Basic Probing & ESSID BruteForce Mode'");
		$basic_num = Count($basic);
		//echo $basic_num;
		$shutdown= db_select($conn, "attack", ['AttType'], "AttType= 'MDK3 - Michael Shutdown Exploitation (TKIP)'");
		$shutdown_num = Count($shutdown);
		//echo $shutdown_num;

		$datas= array($flood_num,$deauthen_num,$beacon_num,$wep_num,$wpa_num, $rogue_num, $confusion_num ,$bruteforce_num,$tkip_num,$basic_num,$shutdown_num);
		
		echo json_encode($datas);
	}

?>