<?php

	require_once ('config.php');
    // Create connection
	/*$conn = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection*/
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}
	//function insert
	function db_insert($conn, $table_name, $columns, $values) {
		$sql="INSERT INTO " . $table_name ." (";
		foreach ($columns as $key) {
			$sql.=$key .",";
		}
		$sql=substr($sql, 0, strlen($sql)-1) .") VALUES (" ;
		foreach ($values as $key) {
			$sql.= $key .",";
		}
		$sql=substr($sql, 0, strlen($sql)-1) .");";
		//print($sql . "<br/>");
		if ($conn->query($sql) === TRUE) {
		    return 1;
		} 
		else {
		    return 0;
		}
	}
	function db_select($conn, $table_name, $columns, $condition = "") {

		$sql = "SELECT" . " ";
		foreach ($columns as $key) {
			$sql.=$key .",";
		}
		$sql=substr($sql, 0, strlen($sql)-1) ." FROM " .$table_name;
		if ($condition != "") {
			$sql.= " WHERE " .$condition;
		}
		//print($sql);
		$result= $conn->query($sql);
		$object=[];
		if ($result->num_rows > 0){
		    while($row = $result->fetch_assoc()) {
		    	$r=[];
		        foreach ($columns as $key) {
		        	$r[$key]= $row[$key];
		        }
		        $object[] =$r;
		    }
		}
		return $object;
		
	}
	function db_selectat($conn) {

		$columns =  ['ID','Reported','AttType','ESSID','ToBSSID'];

		$sql= "SELECT at.ID, at.Reported, at.AttType, at.ToBSSID, ap.ESSID FROM attack at, accesspoint ap WHERE at.ToBSSID = ap.BSSID ORDER BY Reported DESC";
		//print($sql);
		$result= $conn->query($sql);
		$object=[];
		if ($result->num_rows > 0){
		    while($row = $result->fetch_assoc()) {
		    	$r=[];
		        foreach ($columns as $key) {
		        	$r[$key]= $row[$key];
		        }
		        $object[] =$r;
		    }
		}
		return $object;
		
	}
	function db_update ($conn, $table_name, $columns, $values, $condition){

		$sql=" UPDATE " .$table_name ." SET ";
		for ($x = 0; $x < count($columns); $x++ ) {
				$sql.=$columns[$x] ."="  .$values[$x] .",";
		}
		$sql=substr($sql, 0, strlen($sql)-1) . " WHERE " .$condition ;
		//print($sql);
		if ($conn->query($sql) === TRUE) {
		    return 1;
		} 
		else {
		    return 0;
		}
	}
	function db_delete ($conn, $table_name, $condition){

		$sql=" DELETE FROM " .$table_name ." WHERE " .$condition; 
		//print($sql);
		if ($conn->query($sql) === TRUE) {
		    return 1;
		} else {
		    return 0;
		}
	}


 ?>