<?php 
	//require 'database.php';
	
	Function jsontostring ($path){
		$json_text = file_get_contents ($path);
	    $objects = json_decode($json_text);
	    return $json_text; 
	}
	function attack_table($json_string) {
		require 'database.php';
		$table_name ="attack";
	  	// $path = "C:\\xampp\\htdocs\\Webadmin\\File\\WAIDPS-mars-Attacks_new.json";
	   // 	$json_text = file_get_contents ($path);
	    $objects = json_decode($json_string);

	  	foreach ($objects as $obj) {
	   		$Reported = $obj->Reported;
	   		$WIDS = $obj->WIDS;
		   	$arr_attack_log = $obj->AttacksLog;
		   	foreach ($arr_attack_log as $arr) {
			    $ToBSSID = str_replace("'", "''", $arr->ToBSSID); 
 			    $AttNotes = str_replace("'", "''", $arr->AttNotes);
			    $Packets = str_replace("'", "''", $arr->Packets);
			    $FrMAC = str_replace("'", "''", $arr->FrMAC);
			    $ToMAC = str_replace("'", "''", $arr->ToMAC);
			    $FrMACInfo = str_replace("'", "''", $arr->FrMACInfo);
			    $ToBSSIDInfo = str_replace("'", "''", $arr->ToBSSIDInfo);
			    $ToMACInfo = str_replace("'", "''", $arr->ToMACInfo);
			    $AttDetails = str_replace("'", "''", $arr->AttDetails);
			    $AttType = str_replace("'", "''", $arr->AttType);

		    	$columns = ['Reported','WIDS','ToBSSID', 'AttNotes', 'FrMACInfo', 'Packets', 'ToMAC','FrMAC','ToBSSIDInfo','ToMACInfo', 'AttDetails','AttType'];
		    	$values = ["'$Reported'","'$WIDS'","'$ToBSSID'", "'$AttNotes'", "'$FrMACInfo'","'$Packets'", "'$ToMAC'","'$FrMAC'","'$ToBSSIDInfo'","'$ToMACInfo'", "'$AttDetails'","'$AttType'"];
		    	$result = db_insert($conn,$table_name,$columns, $values);
		    	//print $result . "<br/>";

	   		}
  		}
 	}
 	function cautious_table($json_string){
 		require 'database.php';
		$table_name ="cautious";
		//db_delete($conn, $table_name, "1")
	  	// $path = "C:\\xampp\\htdocs\\Webadmin\\File\\WAIDPS-mars-Attacks_new.json";
	   // 	$json_text = file_get_contents ($path);
	    $objects = json_decode($json_string);

	  	foreach ($objects as $obj) {
	   		$Reported = $obj->Reported;
	   		$WIDS = $obj->WIDS;
	   		$Cautious = $obj->Cautious;
		   	$arr_cautious_log = $obj->CautiousLog;
		   	foreach ($arr_cautious_log as $arr) {
			    $CauType = str_replace("'", "''", $arr->CauType); 
 			    $CauInfo = str_replace("'", "''", $arr->CauInfo);
			    $CauDetails = str_replace("'", "''", $arr->CauDetails);
		    	$columns = ['Reported','WIDS','Cautious', 'CauType', 'CauInfo', 'CauDetails'];
		    	$values = ["'$Reported'","'$WIDS'","'$Cautious'", "'$CauType'", "'$CauInfo'","'$CauDetails'"];
		    	$result = db_insert($conn,$table_name,$columns, $values);
		    	//print $result . "<br/>";

	   		}
  		}
 	}
 	function accesspoint_table($json_string) {
 		require 'database.php';
		$table_name ="accesspoint";
	  	/*$path = "C:\\xampp\\htdocs\\Webadmin\\File\\WAIDPS-mars-Attacks_new.json";
	   	$json_text = file_get_contents ($path);*/ 
	    $objects = json_decode($json_string);
	    //db_update($conn,$table_name,["Active"],["0"],"1");
		foreach ($objects as $obj) {
			$WIDS = str_replace("'", "''",$obj->WIDS);
			$Power= str_replace("'", "''",$obj->Power);
			$BSSID= str_replace("'", "''",$obj->BSSID);
			$Privacy = str_replace("'", "''",$obj->Privacy);
			$FirstSeen = str_replace("'", "''",$obj->FirstSeen);
			$WPS = str_replace("'", "''",$obj->WPS);
			$MaxRate = str_replace("'", "''",$obj->MaxRate);
			$Reported = str_replace("'", "''",$obj->Reported);
			$Authentication = str_replace("'", "''",$obj->Authentication);
			$Cipher = str_replace("'", "''",$obj->Cipher);
			$Mode = str_replace("'", "''",$obj->Mode);
			$LastSeen = str_replace("'", "''",$obj->LastSeen);
			$Channel = str_replace("'", "''",$obj->Channel);
			$ESSID = str_replace("'", "''",$obj->ESSID);
			
			$columns=['WIDS','Power', 'BSSID','Privacy','FirstSeen', 'WPS', 'MaxRate','Reported', 'Authentication', 'Cipher', 'Mode', 'LastSeen', 'Channel', 'ESSID','Active'];
			$values= ["'$WIDS'","'$Power'","'$BSSID'","'$Privacy'","'$FirstSeen'","'$WPS'","'$MaxRate'","'$Reported'","'$Authentication'","'$Cipher'","'$Mode'","'$LastSeen'","'$Channel'","'$ESSID'","1"];
			//SELECT COUNT(*) FROM `accesspoint` WHERE BSSID="58:B6:33:93:A8:A9" AND WIDS="mars"
			
			$SQLcheck = "SELECT * FROM accesspoint WHERE WIDS='" .$WIDS ."' AND BSSID='" .$BSSID ."' ";
			$count= $conn->query($SQLcheck);
			if ($count->num_rows < 1){
				$result = db_insert($conn,$table_name,$columns, $values);
			    print $result . "insert<br/>";
			} 
			else {
				$conditions = "WIDS='" .$WIDS ."' AND BSSID='" .$BSSID ."' ";
				$result= db_update($conn,$table_name,$columns, $values,$conditions);
				print $result . "update<br/>";
			}

			
		}		
 	}

 	function station_table($json_string) {
 		require 'database.php';
		$table_name ="station";
	  	/*$path = "C:\\xampp\\htdocs\\Webadmin\\File\\WAIDPS-mars-Attacks_new.json";
	   	$json_text = file_get_contents ($path);*/
	    $objects = json_decode($json_string);

		foreach ($objects as $obj) {

			//$WIDS = str_replace("'", "''",$obj->WIDS);
			$Station = str_replace("'", "''",$obj->Station);
			$ConnectedBSSID = str_replace("'", "''",$obj->ConnectedBSSID);
			$FirstSeen = str_replace("'", "''",$obj->FirstSeen);
			$LastSeen = str_replace("'", "''",$obj->LastSeen);
			$Power = str_replace("'", "''",$obj->Power);
			$Reported = str_replace("'", "''",$obj->Reported);
			$ConnectedESSID = str_replace("'", "''",$obj->ConnectedESSID);

			$columns=['Station','ConnectedBSSID','FirstSeen', 'LastSeen', 'Power', 'Reported', 'ConnectedESSID'];
			$values= ["'$Station'","'$ConnectedBSSID'","'$FirstSeen'","'$LastSeen'","'$Power'","'$Reported'","'$ConnectedESSID'"];
			$result = db_insert($conn,$table_name,$columns, $values);
			//print $result . "<br/>";
		}
 	}
 	function probes_table($json_string) {
 		require 'database.php';
		$table_name ="probes";
	  	/*$path = "C:\\xampp\\htdocs\\Webadmin\\File\\WAIDPS-mars-Attacks_new.json";
	   	$json_text = file_get_contents ($path);*/
	    $objects = json_decode($json_string);

		foreach ($objects as $obj) {

			//$WIDS = str_replace("'", "''",$obj->WIDS);
			$Station = str_replace("'", "''",$obj->Station);
			$Reported = str_replace("'", "''",$obj->Reported);
			$ProbesName = str_replace("'", "''",$obj->ProbesName);

			$columns=['Station','Reported','ProbesName'];
			$values= ["'$Station'","'$Reported'","'$ProbesName'"];
			$result = db_insert($conn,$table_name,$columns, $values);
			//print $result . "<br/>";
		}
 	}
 	function connect ($json_string) {
 		require 'database.php';
 		$table_name ="WIDS";
 		//echo $json_string;
 		$objects = json_decode($json_string);

 		$hostname= $objects[0]->WIDS;
 		//echo $hostname."</br>";
 		$ip = $_SERVER['REMOTE_ADDR'];
 		//$ip = $objects[0]->IP;
 		$mac = "";
 		$arp = 'arp -a '.$ip;
 		$lines = explode("\n",shell_exec($arp));
 		//echo json_encode($lines)."</br>";
 		foreach ($lines as $line) {
 			$cols = preg_split('/\s+/', trim($line));
 			//echo json_encode($cols)."</br>";
 			if ($cols[0] == $ip){
 				$mac = $cols[1];
 			}
 		}
 		$mac = strtoupper($mac);

 		$SQLcheck = "SELECT * FROM WIDS WHERE WIDS='" .$hostname ."' AND MAC='" .$mac ."' ";
			$count= $conn->query($SQLcheck);
			if ($count->num_rows < 1){
				$result = db_insert($conn,$table_name, ['WIDS','IP','MAC'], ["'$hostname'","'$ip'","'$mac'"]);
			    //print $result . "<br/>";
			} 
			else {
				$conditions = "WIDS='" .$hostname ."' AND MAC='" .$mac ."' "; 
				$result= db_update($conn,$table_name, ['Active'],"1",$conditions);
				//print $result . "<br/>";
			}
 		//$result = db_insert($conn, $table_name, ['WIDS','IP'], )
 	}
 	function disconnect ($json_string) {
 		require 'database.php';
 		$table_name ="WIDS";
 		//echo $json_string;
 		$objects = json_decode($json_string);

 		$hostname= $objects[0]->WIDS;
 		//echo $hostname;
 		$ip = $_SERVER['REMOTE_ADDR'];

		$conditions = "WIDS='" .$hostname ."' AND IP='" .$ip ."' "; 
		$result= db_update($conn,$table_name, ['Active'],"0",$conditions);
		db_update($conn,"accesspoint",['Active'],"0","WIDS='$hostname'");
		header('Refresh: 1; url=index.php');
 	}
 	
?>